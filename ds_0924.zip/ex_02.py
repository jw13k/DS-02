age = int(input("나이:"))
grade = input("점수:")
name = input("이름:")

result = "이름은 %s, 나이는 %d, 학점은 %f" % (name, age, grade)
print(result)