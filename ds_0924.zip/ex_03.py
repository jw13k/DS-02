lst = list([50])    #항목 1개 짜리 리스트
size = 50
#lst2 = [None] * 50     #항목 50개 짜리 리스트
lst2 = [None] * size
print(len(lst))
print(len(lst2))