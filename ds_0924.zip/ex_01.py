myStr = "동양미래대"
for i in myStr:
    print(i)

lst = [1,2,3,4,5,6]
mySet = set(lst)
print(mySet)

print(myStr[3])

age = 22
grade = 4.5
name = "홍길동"
result = "이름은 %10s, 나이는 %10d, 학점은 %10.3f" % (name, age, grade)
print(result)